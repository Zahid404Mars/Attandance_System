<?php
include '../assets/sidebar.php';

?>


<div class="team-area">
    <div class="team-container">
      
    </div>
</div>
</div>
</body>

</html>